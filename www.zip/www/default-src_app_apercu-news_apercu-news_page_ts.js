"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_apercu-news_apercu-news_page_ts"],{

/***/ 661:
/*!*************************************************!*\
  !*** ./src/app/apercu-news/apercu-news.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApercuNewsPage": () => (/* binding */ ApercuNewsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _apercu_news_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./apercu-news.page.html?ngResource */ 4962);
/* harmony import */ var _apercu_news_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./apercu-news.page.scss?ngResource */ 5026);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/headline.service */ 1444);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/editor.service */ 2365);
/* harmony import */ var _services_comment_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/comment.service */ 3792);
/* harmony import */ var _models_comment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/comment */ 7296);
/* harmony import */ var _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/utilisateur.service */ 5673);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/alert.service */ 5970);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 8699);












let ApercuNewsPage = class ApercuNewsPage {
    constructor(translate, alertService, toastController, userService, commentService, editorService, navParams, modalCtrl, headlineService) {
        this.translate = translate;
        this.alertService = alertService;
        this.toastController = toastController;
        this.userService = userService;
        this.commentService = commentService;
        this.editorService = editorService;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.headlineService = headlineService;
        this.isLoading = false;
        this.currentEditor = null;
        this.currentComment = [];
        this.currentUser = null;
        this.isComment = false;
        this.writeComment = '';
    }
    ngOnInit() {
        this.headlineService.getHeadlineWitchId(this.navParams.get('idHeadline')).then((data) => {
            this.currentHeadline = data;
            this.editorService.getEditorWitchId(this.currentHeadline.idEditor).then((data1) => {
                this.currentEditor = data1;
            });
            this.commentService.getComments(this.currentHeadline.id).then((data2) => {
                this.currentComment = data2;
            });
            this.userService.getCurrentUtilisateur().then((data3) => {
                this.currentUser = data3;
                if (this.navParams.get('scroollComment') === true) {
                    this.scrollToElement('liste_comment');
                }
            });
        });
    }
    getValueTraduct(texte) {
        let result;
        let result2;
        const result1 = texte.split(this.translate.currentLang + '>');
        if (result1.length > 1) {
            console.log();
            result2 = result1[1].split('</' + this.translate.currentLang + '>');
        }
        if (result1.length > 1 && result2.length > 0) {
            result = result2[0];
        }
        return result ? result : texte;
    }
    shared() {
        navigator.share({
            title: this.currentHeadline.title,
            text: this.currentHeadline.content,
            url: 'https://ayoba-news-headlines.web.app/',
        });
    }
    scrollToElement(element) {
        console.log(element);
        document.getElementById(element).scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
    }
    sendComment(idParent) {
        if (this.writeComment) {
            const tmpComment = new _models_comment__WEBPACK_IMPORTED_MODULE_5__.Comment(this.currentHeadline.id, this.currentUser.id, idParent, this.writeComment);
            this.commentService.addNewComment(tmpComment).then(() => {
                this.currentComment.unshift(tmpComment);
                this.writeComment = '';
                this.isComment = false;
                this.scrollToElement('title_comment');
            });
        }
    }
    like() {
        this.headlineService.likeHeadline(this.currentHeadline).then(() => {
            if (this.currentHeadline.likes.includes(this.currentUser.id)) {
                this.currentHeadline.likes.splice(this.currentHeadline.likes.indexOf(this.currentUser.id), 1);
            }
            else {
                if (this.currentHeadline.disLikes.includes(this.currentUser.id)) {
                    this.dislike();
                }
                this.currentHeadline.likes.push(this.currentUser.id);
            }
        });
    }
    dislike() {
        this.headlineService.disLikeHeadline(this.currentHeadline).then(() => {
            if (this.currentHeadline.disLikes.includes(this.currentUser.id)) {
                this.currentHeadline.disLikes.splice(this.currentHeadline.disLikes.indexOf(this.currentUser.id), 1);
            }
            else {
                if (this.currentHeadline.likes.includes(this.currentUser.id)) {
                    this.like();
                }
                this.currentHeadline.disLikes.push(this.currentUser.id);
            }
        });
    }
    likeCurrentEditor() {
        const tmpCurrentUser = this.currentUser;
        if (tmpCurrentUser.editorsLikes.includes(this.currentEditor.id)) {
            tmpCurrentUser.editorsLikes.splice(tmpCurrentUser.editorsLikes.indexOf(this.currentEditor.id), 1);
        }
        else {
            tmpCurrentUser.editorsLikes.push(this.currentEditor.id);
        }
        this.userService.updateCurrentUser(this.currentUser).then(() => {
            this.currentUser = tmpCurrentUser;
        });
    }
    archiveCurrentHeadline() {
        const tmpCurrentUser = this.currentUser;
        if (tmpCurrentUser.archives.includes(this.currentHeadline.id)) {
            tmpCurrentUser.archives.splice(tmpCurrentUser.archives.indexOf(this.currentHeadline.id), 1);
        }
        else {
            tmpCurrentUser.archives.push(this.currentHeadline.id);
        }
        this.userService.updateCurrentUser(this.currentUser).then(() => {
            let txt1;
            let txt2;
            this.translate.get('5.5-2').subscribe((res) => { txt1 = res; });
            this.translate.get('5.5-3').subscribe((res) => { txt2 = res; });
            this.currentUser = tmpCurrentUser;
            this.alertService.print(tmpCurrentUser.archives.includes(this.currentHeadline.id) ? txt1 : txt2);
        });
    }
    dismissModal() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalCtrl.dismiss({
            dismissed: true
        });
    }
};
ApercuNewsPage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService },
    { type: _services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ToastController },
    { type: _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_6__.UtilisateurService },
    { type: _services_comment_service__WEBPACK_IMPORTED_MODULE_4__.CommentService },
    { type: _services_editor_service__WEBPACK_IMPORTED_MODULE_3__.EditorService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavParams },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _services_headline_service__WEBPACK_IMPORTED_MODULE_2__.HeadlineService }
];
ApercuNewsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-apercu-news',
        template: _apercu_news_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_apercu_news_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ApercuNewsPage);



/***/ }),

/***/ 7296:
/*!***********************************!*\
  !*** ./src/app/models/comment.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Comment": () => (/* binding */ Comment)
/* harmony export */ });
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/tools.service */ 7526);

class Comment {
    constructor(idHeadline, idUser, idParent, text) {
        this.idHeadline = idHeadline;
        this.idUser = idUser;
        this.idParent = idParent;
        this.text = text;
        const gid = new _services_tools_service__WEBPACK_IMPORTED_MODULE_0__.ToolsService();
        this.id = gid.generateId(23);
        this.date = new Date().toString();
        this.likes = [];
        this.disLikes = [];
    }
}


/***/ }),

/***/ 5970:
/*!*******************************************!*\
  !*** ./src/app/services/alert.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertService": () => (/* binding */ AlertService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 3819);




let AlertService = class AlertService {
  constructor(toastController) {
    this.toastController = toastController;
  }

  print(texte) {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toastController.create({
        message: texte,
        duration: 2000,
        position: 'top',
        translucent: true
      });
      yield toast.present();
    })();
  }

};

AlertService.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController
}];

AlertService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], AlertService);


/***/ }),

/***/ 3792:
/*!*********************************************!*\
  !*** ./src/app/services/comment.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommentService": () => (/* binding */ CommentService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ 2451);




let CommentService = class CommentService {
  constructor() {}

  getCommentWitchId(idHeadline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').doc(idHeadline).get().then(docRef => {
          resolve(docRef.data());
        }, error => {
          reject(error);
        });
      });
    })();
  }

  likeComment(comment) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').doc(comment.id).update({
          likes: comment.likes.includes(localStorage.getItem('id')) ? firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id')) : firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayUnion(localStorage.getItem('id')),
          disLikes: firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id'))
        }).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  disLikeComment(comment) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').doc(comment.id).update({
          disLikes: comment.disLikes.includes(localStorage.getItem('id')) ? firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id')) : firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayUnion(localStorage.getItem('id')),
          likes: firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id'))
        }).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  updateComment(comment) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').doc(comment.id).set(Object.assign({}, comment)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getReponseComment(idComment) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').where('idParent', '==', idComment).orderBy('date', 'desc').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getComments(idHeadline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').where('idHeadline', '==', idHeadline).where('idParent', '==', '').orderBy('date', 'desc').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  addNewComment(comment) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('comments').doc(comment.id).set(Object.assign({}, comment)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  addNewReport(report) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('reportsComments').doc(report.id).set(Object.assign({}, report)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

};

CommentService.ctorParameters = () => [];

CommentService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], CommentService);


/***/ }),

/***/ 2365:
/*!********************************************!*\
  !*** ./src/app/services/editor.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditorService": () => (/* binding */ EditorService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ 2451);




let EditorService = class EditorService {
  constructor() {}

  getEditorWitchId(id) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('editors').doc(id).get().then(docRef => {
          resolve(docRef.data());
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getEditorsWitchIdCoverage(idCoverage) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('editors').where('idCoverage', '==', idCoverage).onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getEditors() {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('editors').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  addNewEditor(editor) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('editors').doc(editor.id).set(Object.assign({}, editor)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

};

EditorService.ctorParameters = () => [];

EditorService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], EditorService);


/***/ }),

/***/ 1444:
/*!**********************************************!*\
  !*** ./src/app/services/headline.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeadlineService": () => (/* binding */ HeadlineService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ 2451);




let HeadlineService = class HeadlineService {
  constructor() {}

  getHeadlineWitchId(idHeadline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').doc(idHeadline).get().then(docRef => {
          resolve(docRef.data());
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getHeadlinesWitchText(value) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').where('title', '>=', value).where('title', '<=', value + 'uf8ff').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getHeadlinesWitchIdEditor(idEditor) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').where('idEditor', '==', idEditor).onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getHeadlines() {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').orderBy('date', 'desc').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  addNewHeadline(headline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').doc(headline.id).set(Object.assign({}, headline)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  likeHeadline(headline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tmpH = headline;
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').doc(headline.id).update({
          likes: headline.likes.includes(localStorage.getItem('id')) ? firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id')) : firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayUnion(localStorage.getItem('id')),
          disLikes: firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id'))
        }).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  disLikeHeadline(headline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tmpH = headline;
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('headlines').doc(headline.id).update({
          disLikes: headline.disLikes.includes(localStorage.getItem('id')) ? firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id')) : firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayUnion(localStorage.getItem('id')),
          likes: firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore.FieldValue.arrayRemove(localStorage.getItem('id'))
        }).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

};

HeadlineService.ctorParameters = () => [];

HeadlineService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], HeadlineService);


/***/ }),

/***/ 7526:
/*!*******************************************!*\
  !*** ./src/app/services/tools.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToolsService": () => (/* binding */ ToolsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let ToolsService = class ToolsService {
    dec2hex(dec) {
        return ('0' + dec.toString(16)).substr(-2);
    }
    generateId(len) {
        const arr = new Uint8Array((len || 40) / 2);
        window.crypto.getRandomValues(arr);
        return Array.from(arr, this.dec2hex).join('');
    }
};
ToolsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], ToolsService);



/***/ }),

/***/ 5026:
/*!**************************************************************!*\
  !*** ./src/app/apercu-news/apercu-news.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcGVyY3UtbmV3cy5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 4962:
/*!**************************************************************!*\
  !*** ./src/app/apercu-news/apercu-news.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button [disabled]=\"isLoading\" (click)=\"dismissModal()\" class=\"fs-6 font-medium\">\n        <ion-icon size=\"large\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"font-medium\">{{'4.4-1' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"shared()\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        <ion-icon size=\"large\" name=\"share-social-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-progress-bar color=\"secondary\" *ngIf=\"isLoading\" type=\"indeterminate\"></ion-progress-bar>\n</ion-header>\n\n<ion-content (click)=\"isComment = false\">\n  <section class=\"m-5 border border-gray-300\">\n    <img [src]=\"currentHeadline && currentHeadline.image ? currentHeadline.image : '...'\">\n  </section>\n\n  <section class=\"mx-5\">\n    <h3 class=\"text-2xl text-gray-600\">\n      {{currentEditor ? currentEditor.name : '...'}}\n      <ng-container>\n        <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && !currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 inline-flex\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z\" />\n        </svg>\n        <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-red-500 inline-flex\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path fill-rule=\"evenodd\" d=\"M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z\" clip-rule=\"evenodd\" />\n        </svg>\n      </ng-container>\n    </h3>\n    <span class=\"text-orange-600\">\n      {{currentHeadline ? (currentHeadline.date | date : 'dd/MM/yyyy') : '...'}}\n    </span>\n    <br>\n    <small class=\"ion-text-left truncate text-gray-600\">{{currentHeadline ? getValueTraduct(currentHeadline.title) : '...'}}</small>\n    <p class=\"text-gray-500 py-3\" [innerHTML]=\"currentHeadline ? getValueTraduct(currentHeadline.content) : '...'\"></p>\n  </section>\n  <section class=\"px-5 mb-2\" id=\"title_comment\">\n    <span class=\"font-bold text-blue-900\">{{'4.4-2' | translate}} ({{currentComment.length}})</span>\n  </section>\n  <section class=\"px-5\" id=\"liste_comment\">\n    <app-miniature-comment [idComment]=\"comment.id\" *ngFor=\"let comment of currentComment\"></app-miniature-comment>\n  </section>\n</ion-content>\n\n<ion-footer collapse=\"fade\">\n  <ion-toolbar class=\"px-2\">\n    <textarea *ngIf=\"isComment\" [(ngModel)]=\"writeComment\" [rows]=\"isComment ? '3' : '1'\" placeholder=\"{{'4-6' | translate}}\" id=\"input-comment\" class=\"{{isComment ? 'my-2' : ''}} bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500\" required></textarea>\n    <ion-buttons slot=\"end\">\n      <ion-button *ngIf=\"!isComment\" (click)=\"isComment = true\">\n        <ion-chip class=\"text-sm capitalize px-3\" color=\"primary\" mode=\"ios\">\n          <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 animate-pulse\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z\" />\n          </svg> &nbsp;\n          <ion-label>{{'4.4-3' | translate}}</ion-label>\n        </ion-chip>\n      </ion-button>\n      <ion-button *ngIf=\"isComment\" (click)=\"sendComment('');\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        <ion-icon [color]=\"writeComment ? 'secondary' : 'medium'\" name=\"send-sharp\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"scrollToElement('liste_comment')\" *ngIf=\"currentUser && !isComment\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        {{currentHeadline ? currentComment.length : '...'}}&nbsp;\n        <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z\" />\n        </svg>\n      </ion-button>\n      <ion-button *ngIf=\"currentUser && !isComment\" (click)=\"archiveCurrentHeadline()\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        <svg *ngIf=\"!currentUser.archives.includes(currentHeadline.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\" />\n        </svg>\n        <svg *ngIf=\"currentUser.archives.includes(currentHeadline.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-orange-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path d=\"M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z\" />\n        </svg>\n      </ion-button>\n      <ion-button (click)=\"like()\" *ngIf=\"currentUser && !isComment\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        <ng-container>\n          {{currentHeadline.likes.length}}&nbsp;\n          <svg *ngIf=\"currentUser && !currentHeadline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5\" />\n          </svg>\n          <svg *ngIf=\"currentUser && currentHeadline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-blue-900\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z\" />\n          </svg>\n        </ng-container>\n      </ion-button>\n      <ion-button (click)=\"dislike()\" *ngIf=\"currentUser && !isComment\" [disabled]=\"isLoading\" class=\"fs-6 font-medium\">\n        <ng-container>\n          {{currentHeadline.disLikes.length}}&nbsp;\n          <svg *ngIf=\"currentUser && !currentHeadline.disLikes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2m5-10h2a2 2 0 012 2v6a2 2 0 01-2 2h-2.5\" />\n          </svg>\n          <svg *ngIf=\"currentUser && currentHeadline.disLikes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-red-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M18 9.5a1.5 1.5 0 11-3 0v-6a1.5 1.5 0 013 0v6zM14 9.667v-5.43a2 2 0 00-1.105-1.79l-.05-.025A4 4 0 0011.055 2H5.64a2 2 0 00-1.962 1.608l-1.2 6A2 2 0 004.44 12H8v4a2 2 0 002 2 1 1 0 001-1v-.667a4 4 0 01.8-2.4l1.4-1.866a4 4 0 00.8-2.4z\" />\n          </svg>\n        </ng-container>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_apercu-news_apercu-news_page_ts.js.map