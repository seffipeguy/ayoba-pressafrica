"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_tab1_tab1_module_ts"],{

/***/ 4762:
/*!******************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExploreContainerComponent": () => (/* binding */ ExploreContainerComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _explore_container_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./explore-container.component.html?ngResource */ 959);
/* harmony import */ var _explore_container_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./explore-container.component.scss?ngResource */ 1509);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);




let ExploreContainerComponent = class ExploreContainerComponent {
    constructor() { }
    ngOnInit() { }
};
ExploreContainerComponent.ctorParameters = () => [];
ExploreContainerComponent.propDecorators = {
    name: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
ExploreContainerComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-explore-container',
        template: _explore_container_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_explore_container_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ExploreContainerComponent);



/***/ }),

/***/ 581:
/*!***************************************************************!*\
  !*** ./src/app/explore-container/explore-container.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExploreContainerComponentModule": () => (/* binding */ ExploreContainerComponentModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _explore_container_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./explore-container.component */ 4762);






let ExploreContainerComponentModule = class ExploreContainerComponentModule {
};
ExploreContainerComponentModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule],
        declarations: [_explore_container_component__WEBPACK_IMPORTED_MODULE_0__.ExploreContainerComponent],
        exports: [_explore_container_component__WEBPACK_IMPORTED_MODULE_0__.ExploreContainerComponent]
    })
], ExploreContainerComponentModule);



/***/ }),

/***/ 7242:
/*!******************************************************!*\
  !*** ./src/app/services/categorie-editor.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategorieEditorService": () => (/* binding */ CategorieEditorService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ 2451);




let CategorieEditorService = class CategorieEditorService {
  constructor() {}

  addCategorie(categorie) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('categoriesEditors').doc(categorie.id).set(Object.assign({}, categorie)).then(() => {
          resolve();
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getCategorie() {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('categoriesEditors').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

};

CategorieEditorService.ctorParameters = () => [];

CategorieEditorService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], CategorieEditorService);


/***/ }),

/***/ 393:
/*!**********************************************!*\
  !*** ./src/app/services/coverage.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoverageService": () => (/* binding */ CoverageService)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ 2451);




let CoverageService = class CoverageService {
  constructor() {}

  getAllCoverage() {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        // @ts-ignore
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('coverage').onSnapshot(docRef => {
          const result = [];
          docRef.forEach(function (doc) {
            result.push(doc.data());
          });
          resolve(result);
        }, error => {
          reject(error);
        });
      });
    })();
  }

  getCoverageWitchId(idHeadline) {
    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        firebase__WEBPACK_IMPORTED_MODULE_1__["default"].firestore().collection('coverage').doc(idHeadline).get().then(docRef => {
          resolve(docRef.data());
        }, error => {
          reject(error);
        });
      });
    })();
  }

};

CoverageService.ctorParameters = () => [];

CoverageService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], CoverageService);


/***/ }),

/***/ 9492:
/*!***************************************************************************!*\
  !*** ./src/app/shared/miniature-headline/miniature-headline.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MiniatureHeadlineComponent": () => (/* binding */ MiniatureHeadlineComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _miniature_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./miniature-headline.component.html?ngResource */ 5312);
/* harmony import */ var _miniature_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./miniature-headline.component.scss?ngResource */ 879);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _apercu_news_apercu_news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../apercu-news/apercu-news.page */ 661);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/headline.service */ 1444);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/editor.service */ 2365);
/* harmony import */ var _services_comment_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/comment.service */ 3792);
/* harmony import */ var _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/utilisateur.service */ 5673);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/alert.service */ 5970);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 8699);













let MiniatureHeadlineComponent = class MiniatureHeadlineComponent {
  constructor(translate, alertService, userService, commentService, modalController, headlineService, editorService) {
    this.translate = translate;
    this.alertService = alertService;
    this.userService = userService;
    this.commentService = commentService;
    this.modalController = modalController;
    this.headlineService = headlineService;
    this.editorService = editorService;
    this.skin = 'block';
    this.currentHedline = null;
    this.currentEditor = null;
    this.currentComment = [];
    this.currentUser = null;
  }

  ngOnInit() {
    this.headlineService.getHeadlineWitchId(this.idHeadline).then(data => {
      this.currentHedline = data;
      this.editorService.getEditorWitchId(this.currentHedline.idEditor).then(data1 => {
        this.currentEditor = data1;
      });
      this.commentService.getComments(this.currentHedline.id).then(data2 => {
        this.currentComment = data2;
      });
      this.userService.getCurrentUtilisateur().then(data3 => {
        this.currentUser = data3;
      });
    });
  }

  getValueTraduct(texte) {
    let result;
    let result2;
    const result1 = texte.split(this.translate.currentLang + '>');

    if (result1.length > 1) {
      console.log();
      result2 = result1[1].split('</');
    }

    if (result1.length > 1 && result2.length > 0) {
      result = result2[0];
    }

    return result ? result : texte;
  }

  likeCurrentEditor() {
    const tmpCurrentUser = this.currentUser;

    if (tmpCurrentUser.editorsLikes.includes(this.currentEditor.id)) {
      tmpCurrentUser.editorsLikes.splice(tmpCurrentUser.editorsLikes.indexOf(this.currentEditor.id), 1);
    } else {
      tmpCurrentUser.editorsLikes.push(this.currentEditor.id);
    }

    this.userService.updateCurrentUser(this.currentUser).then(() => {
      this.currentUser = tmpCurrentUser;
    });
  }

  likeCurrentHeadline() {
    this.headlineService.likeHeadline(this.currentHedline).then(() => {
      if (this.currentHedline.likes.includes(this.currentUser.id)) {
        this.currentHedline.likes.splice(this.currentHedline.likes.indexOf(this.currentUser.id), 1);
      } else {
        if (this.currentHedline.disLikes.includes(this.currentUser.id)) {
          this.disLikeCurrentHeadline();
        }

        this.currentHedline.likes.push(this.currentUser.id);
      }
    });
  }

  disLikeCurrentHeadline() {
    this.headlineService.disLikeHeadline(this.currentHedline).then(() => {
      if (this.currentHedline.disLikes.includes(this.currentUser.id)) {
        this.currentHedline.disLikes.splice(this.currentHedline.disLikes.indexOf(this.currentUser.id), 1);
      } else {
        if (this.currentHedline.likes.includes(this.currentUser.id)) {
          this.likeCurrentHeadline();
        }

        this.currentHedline.disLikes.push(this.currentUser.id);
      }
    });
  }

  archiveCurrentHeadline() {
    const tmpCurrentUser = this.currentUser;

    if (tmpCurrentUser.archives.includes(this.currentHedline.id)) {
      tmpCurrentUser.archives.splice(tmpCurrentUser.archives.indexOf(this.currentHedline.id), 1);
    } else {
      tmpCurrentUser.archives.push(this.currentHedline.id);
    }

    this.userService.updateCurrentUser(this.currentUser).then(() => {
      this.currentUser = tmpCurrentUser;
      this.alertService.print(tmpCurrentUser.archives.includes(this.currentHedline.id) ? 'The article has been successfully added to the archive' : 'The article has been successfully removed from the archive');
    });
  }

  btnApercuNews(valeur) {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _apercu_news_apercu_news_page__WEBPACK_IMPORTED_MODULE_3__.ApercuNewsPage,
        componentProps: {
          idHeadline: _this.idHeadline,
          scroollComment: valeur
        }
      });
      return yield modal.present();
    })();
  }

};

MiniatureHeadlineComponent.ctorParameters = () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService
}, {
  type: _services_alert_service__WEBPACK_IMPORTED_MODULE_8__.AlertService
}, {
  type: _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_7__.UtilisateurService
}, {
  type: _services_comment_service__WEBPACK_IMPORTED_MODULE_6__.CommentService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController
}, {
  type: _services_headline_service__WEBPACK_IMPORTED_MODULE_4__.HeadlineService
}, {
  type: _services_editor_service__WEBPACK_IMPORTED_MODULE_5__.EditorService
}];

MiniatureHeadlineComponent.propDecorators = {
  idHeadline: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input
  }],
  idCategory: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input
  }],
  skin: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input
  }]
};
MiniatureHeadlineComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-miniature-headline',
  template: _miniature_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_miniature_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MiniatureHeadlineComponent);


/***/ }),

/***/ 6580:
/*!***************************************************************************!*\
  !*** ./src/app/shared/print-all-coverage/print-all-coverage.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrintAllCoverageComponent": () => (/* binding */ PrintAllCoverageComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _print_all_coverage_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./print-all-coverage.component.html?ngResource */ 1757);
/* harmony import */ var _print_all_coverage_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./print-all-coverage.component.scss?ngResource */ 8695);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_coverage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/coverage.service */ 393);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/editor.service */ 2365);






let PrintAllCoverageComponent = class PrintAllCoverageComponent {
    constructor(coverageService, editorService) {
        this.coverageService = coverageService;
        this.editorService = editorService;
        this.listeCoverage = [];
        this.headlines = [];
        this.editors = [];
        this.idCat = '';
    }
    ngOnChanges(changes) {
        this.idCat = this.idCategory;
        this.ngOnInit();
    }
    ngOnInit() {
        this.idCat = this.idCategory;
        this.coverageService.getAllCoverage().then((data) => {
            this.listeCoverage = data;
        });
        this.editorService.getEditors().then((data) => {
            this.editors = data;
        });
    }
    filtreHeadlineWitchCoverage(idCoverage) {
        console.log(idCoverage);
        const result = [];
        for (let i = 0; i < this.headlines.length; i++) {
            if (this.getCoverageWitchEditor(this.headlines[i].idEditor) === idCoverage) {
                result.push(this.headlines[i]);
            }
        }
        return result;
    }
    getCoverageWitchEditor(idEditor) {
        let result;
        for (let i = 0; i < this.editors.length; i++) {
            if (idEditor === this.editors[i].id) {
                result = this.editors[i].idCoverage;
                return result;
            }
        }
    }
};
PrintAllCoverageComponent.ctorParameters = () => [
    { type: _services_coverage_service__WEBPACK_IMPORTED_MODULE_2__.CoverageService },
    { type: _services_editor_service__WEBPACK_IMPORTED_MODULE_3__.EditorService }
];
PrintAllCoverageComponent.propDecorators = {
    idCategory: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
PrintAllCoverageComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-print-all-coverage',
        template: _print_all_coverage_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_print_all_coverage_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PrintAllCoverageComponent);



/***/ }),

/***/ 5142:
/*!*********************************************************************************!*\
  !*** ./src/app/shared/print-recent-headline/print-recent-headline.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrintRecentHeadlineComponent": () => (/* binding */ PrintRecentHeadlineComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _print_recent_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./print-recent-headline.component.html?ngResource */ 1969);
/* harmony import */ var _print_recent_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./print-recent-headline.component.scss?ngResource */ 7932);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/headline.service */ 1444);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/editor.service */ 2365);







let PrintRecentHeadlineComponent = class PrintRecentHeadlineComponent {
  constructor(headlineService, editorService) {
    this.headlineService = headlineService;
    this.editorService = editorService;
    this.slideOptsNews = {
      initialSlide: 0,
      speed: 800,
      slidesPerView: 1.7,
      spaceBetween: 10,
      slidesOffsetBefore: 10,
      slidesOffsetAfter: 10
    };
    this.headlines = [];
    this.listAllHeadline = [];
  }

  ngOnInit() {
    this.headlineService.getHeadlines().then(data => {
      const pointe = this;
      this.listAllHeadline = data;
      this.listAllHeadline.forEach(function (doc) {
        if (pointe.idCategory !== '') {
          pointe.filtreHeadline(doc.idEditor).then(result => {
            if (result) {
              pointe.headlines.push(doc);
            }
          });
        } else {
          pointe.headlines.push(doc);
        }
      });
    });
  }

  ngOnChanges(changes) {
    const pointe = this;
    this.headlines = []; // eslint-disable-next-line prefer-arrow/prefer-arrow-functions

    this.listAllHeadline.forEach(function (doc) {
      if (pointe.idCategory !== '') {
        pointe.filtreHeadline(doc.idEditor).then(result => {
          if (result) {
            pointe.headlines.push(doc);
          }
        });
      } else {
        pointe.headlines.push(doc);
      }
    });
  }

  filtreHeadline(idEditor) {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        _this.editorService.getEditorWitchId(idEditor).then(data => {
          if (data.idCategory === _this.idCategory) {
            resolve(true);
          } else {
            resolve(false);
          }
        });
      });
    })();
  }

};

PrintRecentHeadlineComponent.ctorParameters = () => [{
  type: _services_headline_service__WEBPACK_IMPORTED_MODULE_3__.HeadlineService
}, {
  type: _services_editor_service__WEBPACK_IMPORTED_MODULE_4__.EditorService
}];

PrintRecentHeadlineComponent.propDecorators = {
  idCategory: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }]
};
PrintRecentHeadlineComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-print-recent-headline',
  template: _print_recent_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_print_recent_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], PrintRecentHeadlineComponent);


/***/ }),

/***/ 5021:
/*!***********************************************************************!*\
  !*** ./src/app/shared/print-x-coverage/print-x-coverage.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrintXCoverageComponent": () => (/* binding */ PrintXCoverageComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _print_x_coverage_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./print-x-coverage.component.html?ngResource */ 8753);
/* harmony import */ var _print_x_coverage_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./print-x-coverage.component.scss?ngResource */ 4209);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/headline.service */ 1444);
/* harmony import */ var _services_coverage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/coverage.service */ 393);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/editor.service */ 2365);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);









let PrintXCoverageComponent = class PrintXCoverageComponent {
  constructor(translate, headlineService, coverageService, editorService) {
    this.translate = translate;
    this.headlineService = headlineService;
    this.coverageService = coverageService;
    this.editorService = editorService;
    this.listeEditor = [];
    this.headlines = [];
    this.slideOptsNews = {
      initialSlide: 0,
      speed: 800,
      slidesPerView: 1.7,
      spaceBetween: 10,
      slidesOffsetBefore: 10,
      slidesOffsetAfter: 10
    };
  }

  ngOnInit() {
    this.coverageService.getCoverageWitchId(this.idCoverage).then(data => {
      this.currentCoverage = data;
    });
    this.editorService.getEditorsWitchIdCoverage(this.idCoverage).then(data1 => {
      this.listeEditor = data1;
      const pointe = this;
      data1.forEach(function (doc) {
        pointe.headlineService.getHeadlinesWitchIdEditor(doc.id).then(data2 => {
          data2.forEach(function (doc2) {
            pointe.headlines.push(doc2);
          });
        });
      });
    });
  }

  ngOnChanges(changes) {
    const pointe = this;
    this.headlines = []; // eslint-disable-next-line prefer-arrow/prefer-arrow-functions

    this.headlines.forEach(function (doc) {
      if (pointe.idCategory !== '') {
        pointe.filtreHeadline(doc.idEditor).then(result => {
          if (result) {
            pointe.headlines.push(doc);
          }
        });
      } else {
        pointe.headlines.push(doc);
      }
    });
  }

  getValueTraduct(texte) {
    let result;
    let result2;
    const result1 = texte.split(this.translate.currentLang + '>');

    if (result1.length > 1) {
      console.log();
      result2 = result1[1].split('</');
    }

    if (result1.length > 1 && result2.length > 0) {
      result = result2[0];
    }

    return result ? result : texte;
  }

  filtreHeadline(idEditor) {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        _this.editorService.getEditorWitchId(idEditor).then(data => {
          if (data.idCategory === _this.idCategory) {
            resolve(true);
          } else {
            resolve(false);
          }
        });
      });
    })();
  }

};

PrintXCoverageComponent.ctorParameters = () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService
}, {
  type: _services_headline_service__WEBPACK_IMPORTED_MODULE_3__.HeadlineService
}, {
  type: _services_coverage_service__WEBPACK_IMPORTED_MODULE_4__.CoverageService
}, {
  type: _services_editor_service__WEBPACK_IMPORTED_MODULE_5__.EditorService
}];

PrintXCoverageComponent.propDecorators = {
  idCategory: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }],
  idCoverage: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }]
};
PrintXCoverageComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-print-x-coverage',
  template: _print_x_coverage_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_print_x_coverage_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], PrintXCoverageComponent);


/***/ }),

/***/ 1115:
/*!***********************************************************************************!*\
  !*** ./src/app/shared/result-search-headline/result-search-headline.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResultSearchHeadlineComponent": () => (/* binding */ ResultSearchHeadlineComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _result_search_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./result-search-headline.component.html?ngResource */ 4594);
/* harmony import */ var _result_search_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./result-search-headline.component.scss?ngResource */ 9130);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/headline.service */ 1444);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/editor.service */ 2365);







let ResultSearchHeadlineComponent = class ResultSearchHeadlineComponent {
  constructor(headlineService, editorService) {
    this.headlineService = headlineService;
    this.editorService = editorService;
    this.texte = '';
    this.idCategory = '';
    this.listAllHeadline = [];
    this.headlines = [];
  }

  ngOnInit() {
    this.headlines = [];
    /*const pointe = this;
    this.headlines = [];
    // eslint-disable-next-line prefer-arrow/prefer-arrow-functions
    this.listAllHeadline.forEach(function(doc) {
      if(pointe.idCategory !== '') {
        pointe.filtreHeadline(doc.idEditor).then(
          (result) => {
            if(result) {
              pointe.headlines.push(doc);
            }
          }
        );
      } else {
        pointe.headlines.push(doc);
      }
    });*/
  }

  ngOnChanges() {
    if (this.texte !== '') {
      this.headlineService.getHeadlinesWitchText(this.texte).then(data => {
        this.listAllHeadline = data;
        const pointe = this;
        this.headlines = []; // eslint-disable-next-line prefer-arrow/prefer-arrow-functions

        this.listAllHeadline.forEach(function (doc) {
          if (pointe.idCategory !== '') {
            pointe.filtreHeadline(doc.idEditor).then(result => {
              if (result) {
                pointe.headlines.push(doc);
              }
            });
          } else {
            pointe.headlines.push(doc);
          }
        });
      });
    }
  }

  filtreHeadline(idEditor) {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return new Promise((resolve, reject) => {
        _this.editorService.getEditorWitchId(idEditor).then(data => {
          if (data.idCategory === _this.idCategory) {
            resolve(true);
          } else {
            resolve(false);
          }
        });
      });
    })();
  }

};

ResultSearchHeadlineComponent.ctorParameters = () => [{
  type: _services_headline_service__WEBPACK_IMPORTED_MODULE_3__.HeadlineService
}, {
  type: _services_editor_service__WEBPACK_IMPORTED_MODULE_4__.EditorService
}];

ResultSearchHeadlineComponent.propDecorators = {
  texte: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  idCategory: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }]
};
ResultSearchHeadlineComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-result-search-headline',
  template: _result_search_headline_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_result_search_headline_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ResultSearchHeadlineComponent);


/***/ }),

/***/ 2580:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page,
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ 2168:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 581);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1-routing.module */ 2580);
/* harmony import */ var _shared_miniature_headline_miniature_headline_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/miniature-headline/miniature-headline.component */ 9492);
/* harmony import */ var _shared_print_recent_headline_print_recent_headline_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/print-recent-headline/print-recent-headline.component */ 5142);
/* harmony import */ var _shared_result_search_headline_result_search_headline_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/result-search-headline/result-search-headline.component */ 1115);
/* harmony import */ var _shared_print_all_coverage_print_all_coverage_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/print-all-coverage/print-all-coverage.component */ 6580);
/* harmony import */ var _shared_print_x_coverage_print_x_coverage_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/print-x-coverage/print-x-coverage.component */ 5021);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 8699);














let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab1PageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateModule
        ],
        exports: [
            _shared_miniature_headline_miniature_headline_component__WEBPACK_IMPORTED_MODULE_3__.MiniatureHeadlineComponent
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page, _shared_miniature_headline_miniature_headline_component__WEBPACK_IMPORTED_MODULE_3__.MiniatureHeadlineComponent, _shared_print_recent_headline_print_recent_headline_component__WEBPACK_IMPORTED_MODULE_4__.PrintRecentHeadlineComponent, _shared_result_search_headline_result_search_headline_component__WEBPACK_IMPORTED_MODULE_5__.ResultSearchHeadlineComponent, _shared_print_all_coverage_print_all_coverage_component__WEBPACK_IMPORTED_MODULE_6__.PrintAllCoverageComponent, _shared_print_x_coverage_print_x_coverage_component__WEBPACK_IMPORTED_MODULE_7__.PrintXCoverageComponent]
    })
], Tab1PageModule);



/***/ }),

/***/ 6923:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1.page.html?ngResource */ 3852);
/* harmony import */ var _tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1.page.scss?ngResource */ 8165);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_categorie_editor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/categorie-editor.service */ 7242);
/* harmony import */ var _services_pays_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/pays.service */ 2786);
/* harmony import */ var _services_headline_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/headline.service */ 1444);
/* harmony import */ var _services_editor_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/editor.service */ 2365);
/* harmony import */ var _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/utilisateur.service */ 5673);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/alert.service */ 5970);













let Tab1Page = class Tab1Page {
  constructor(alertService, translate, userService, categorieEditeur, editorService, headlineService, paysService, categorieEditorService, modalController, alertController) {
    this.alertService = alertService;
    this.translate = translate;
    this.userService = userService;
    this.categorieEditeur = categorieEditeur;
    this.editorService = editorService;
    this.headlineService = headlineService;
    this.paysService = paysService;
    this.categorieEditorService = categorieEditorService;
    this.modalController = modalController;
    this.alertController = alertController;
    this.categorieSelect = null;
    this.paySelect = null;
    this.isSearch = false;
    this.headlines = [];
    this.categoriesEditors = [];
    this.inputListCategorie = [];
    this.inputPays = [];
    this.currentUser = null;
    this.currentSearch = '';
    this.slideOpts = {
      initialSlide: 0,
      speed: 800,
      slidesPerView: 0,
      spaceBetween: 10,
      slidesOffsetBefore: 10,
      slidesOffsetAfter: 10
    };
  }

  ngOnInit() {
    //localStorage.clear();
    //localStorage.setItem('id', '690689765');

    /*
    this.categorieEditeur.addCategorie(new CategorieEditor('economie')).then(
      () => {
        alert('Ajouter avec succes');
      }
    );
     */

    /*
    this.headlineService.addNewHeadline(new Headline('037cc7608d5c4f51e5c993', 'N° 7853', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '14 juillet 2022')).then(
      () => {
        alert('Ajouter avec succes');
      }
    );
    */

    /*this.editorService.addNewEditor(new Editor('Sans détour', 'Journal 123', '1','1','1')).then(
      () => {
        alert('Ajouter avec succes');
      });*/
    this.userService.getCurrentUtilisateur().then(data => {
      this.currentUser = data;

      if (this.currentUser.idCountry) {
        this.paysService.getPaysWitchId(this.currentUser.idCountry).then(data5 => {
          this.paySelect = data5;
          this.paysService.getPays().then(data8 => {
            for (let i = 0; i < data8.length; i++) {
              this.inputPays.push({
                label: data8[i].name,
                type: 'radio',
                value: data8[i],
                checked: this.paySelect.id === data8[i].id
              });
            }
          });
        });
      } else {
        this.paysService.getPays().then(data8 => {
          for (let i = 0; i < data8.length; i++) {
            this.inputPays.push({
              label: data8[i].name,
              type: 'radio',
              value: data8[i]
            });
          }
        });
      }
    });
    this.categorieEditorService.getCategorie().then(data => {
      this.categoriesEditors = data;
      let txt1;
      this.translate.get('1.1-7').subscribe(res => {
        txt1 = res;
      });
      this.inputListCategorie.push({
        label: txt1,
        type: 'radio',
        value: null,
        checked: !this.categorieSelect
      });

      for (let i = 0; i < this.categoriesEditors.length; i++) {
        this.inputListCategorie.push({
          label: this.getValueTraduct(this.categoriesEditors[i].name),
          type: 'radio',
          value: this.categoriesEditors[i],
          checked: this.categorieSelect && this.categorieSelect.id === this.categoriesEditors[i].id
        });
      }
    });
  }

  presentAllCountry() {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let txt1;
      let txt2;

      _this.translate.get('1.1-6').subscribe(res => {
        txt1 = res;
      });

      _this.translate.get('1.1-10').subscribe(res => {
        txt2 = res;
      });

      const alert = yield _this.alertController.create({
        header: txt1,
        buttons: [{
          text: 'OK',
          role: 'confirm',
          handler: paysChoice => {
            if (!_this.paySelect || _this.paySelect.id !== paysChoice.id) {
              _this.paySelect = paysChoice;
              _this.currentUser.idCountry = _this.paySelect.id;
              localStorage.setItem('language', _this.paySelect.language.toLocaleLowerCase());

              _this.translate.use(_this.paySelect.language.toLocaleLowerCase());

              _this.userService.updateCurrentUser(_this.currentUser).then(() => {
                _this.currentUser.idCountry = _this.paySelect.id;

                _this.alertService.print(txt2);
              });
            }
          }
        }],
        inputs: _this.inputPays
      });
      yield alert.present();
    })();
  }

  getValueTraduct(texte) {
    let result;
    let result2;
    const result1 = texte.split(this.translate.currentLang + '>');

    if (result1.length > 1) {
      console.log();
      result2 = result1[1].split('</');
    }

    if (result1.length > 1 && result2.length > 0) {
      result = result2[0];
    }

    return result ? result : texte;
  }

  presentAllCategorie() {
    var _this2 = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let txt1;

      _this2.translate.get('1.1-7').subscribe(res => {
        txt1 = res;
      });

      const alert = yield _this2.alertController.create({
        header: txt1,
        buttons: [{
          text: 'OK',
          role: 'confirm',
          handler: categorieChoice => {
            _this2.categorieSelect = categorieChoice;
          }
        }],
        inputs: _this2.inputListCategorie,
        animated: true
      });
      yield alert.present();
    })();
  }

};

Tab1Page.ctorParameters = () => [{
  type: _services_alert_service__WEBPACK_IMPORTED_MODULE_8__.AlertService
}, {
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService
}, {
  type: _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_7__.UtilisateurService
}, {
  type: _services_categorie_editor_service__WEBPACK_IMPORTED_MODULE_3__.CategorieEditorService
}, {
  type: _services_editor_service__WEBPACK_IMPORTED_MODULE_6__.EditorService
}, {
  type: _services_headline_service__WEBPACK_IMPORTED_MODULE_5__.HeadlineService
}, {
  type: _services_pays_service__WEBPACK_IMPORTED_MODULE_4__.PaysService
}, {
  type: _services_categorie_editor_service__WEBPACK_IMPORTED_MODULE_3__.CategorieEditorService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.AlertController
}];

Tab1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
  selector: 'app-tab1',
  template: _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab1Page);


/***/ }),

/***/ 1509:
/*!*******************************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV4cGxvcmUtY29udGFpbmVyLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1ycyUyMFNFRkZJXFxEb2N1bWVudHNcXHByb2pldCUyMGlvbmljJTIwemVuJTIwYWZyaWNhXFxheW9iYS1uZXdzXFxzcmNcXGFwcFxcZXhwbG9yZS1jb250YWluZXJcXGV4cGxvcmUtY29udGFpbmVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFFQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FDQUY7O0FER0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUNBRjs7QURHQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUVBLGNBQUE7RUFFQSxTQUFBO0FDRkY7O0FES0E7RUFDRSxxQkFBQTtBQ0ZGIiwiZmlsZSI6ImV4cGxvcmUtY29udGFpbmVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuXG4jY29udGFpbmVyIHN0cm9uZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG5cbiAgY29sb3I6ICM4YzhjOGM7XG5cbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59IiwiI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59Il19 */";

/***/ }),

/***/ 879:
/*!****************************************************************************************!*\
  !*** ./src/app/shared/miniature-headline/miniature-headline.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtaW5pYXR1cmUtaGVhZGxpbmUuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 8695:
/*!****************************************************************************************!*\
  !*** ./src/app/shared/print-all-coverage/print-all-coverage.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmludC1hbGwtY292ZXJhZ2UuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 7932:
/*!**********************************************************************************************!*\
  !*** ./src/app/shared/print-recent-headline/print-recent-headline.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmludC1yZWNlbnQtaGVhZGxpbmUuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 4209:
/*!************************************************************************************!*\
  !*** ./src/app/shared/print-x-coverage/print-x-coverage.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmludC14LWNvdmVyYWdlLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 9130:
/*!************************************************************************************************!*\
  !*** ./src/app/shared/result-search-headline/result-search-headline.component.scss?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXN1bHQtc2VhcmNoLWhlYWRsaW5lLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 8165:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --ion-background-color:#F5F5F5;\n}\n\n.swiper-slide {\n  width: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjEucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXE1ycyUyMFNFRkZJXFxEb2N1bWVudHNcXHByb2pldCUyMGlvbmljJTIwemVuJTIwYWZyaWNhXFxheW9iYS1uZXdzXFxzcmNcXGFwcFxcdGFiMVxcdGFiMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw4QkFBQTtBQ0NGOztBREVBO0VBQ0UsV0FBQTtBQ0NGIiwiZmlsZSI6InRhYjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojRjVGNUY1O1xyXG59XHJcblxyXG4uc3dpcGVyLXNsaWRlIHtcclxuICB3aWR0aDogYXV0bztcclxufVxyXG4iLCJpb24tY29udGVudCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6I0Y1RjVGNTtcbn1cblxuLnN3aXBlci1zbGlkZSB7XG4gIHdpZHRoOiBhdXRvO1xufSJdfQ== */";

/***/ }),

/***/ 959:
/*!*******************************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = "<div id=\"container\">\n  <strong>{{ name }}</strong>\n  <p>Explore <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://ionicframework.com/docs/components\">UI Components</a></p>\n</div>";

/***/ }),

/***/ 5312:
/*!****************************************************************************************!*\
  !*** ./src/app/shared/miniature-headline/miniature-headline.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"py-5 px-3 max-w-sm bg-white rounded-lg shadow-md dark:bg-gray-800 dark:border-gray-700\" *ngIf=\"skin === 'block' && currentHedline && currentEditor && (idCategory === '' || currentEditor.idCategory === idCategory)\">\n  <div class=\"h-60 overflow-auto overscroll-y-none overscroll-x-none overscroll-none\" (click)=\"btnApercuNews(false)\">\n    <img class=\"rounded-t-lg\" [src]=\"currentHedline && currentHedline.image ? currentHedline.image : '...'\" alt=\"Loading...\">\n  </div>\n  <div (click)=\"btnApercuNews(false)\" class=\"grid grid-cols-2 text-gray-500 py-1\">\n    <small class=\"ion-text-left truncate\">{{getValueTraduct(currentHedline.title)}}</small>\n    <small class=\"ion-text-right truncate\">{{currentHedline.dateParution | date : 'd/M/yy'}}</small>\n  </div>\n  <div class=\"flex items-center ion-align-items-center\" *ngIf=\"currentEditor\">\n    <ng-container>\n      <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && !currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n        <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z\" />\n      </svg>\n      <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-red-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n        <path fill-rule=\"evenodd\" d=\"M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z\" clip-rule=\"evenodd\" />\n      </svg>\n    </ng-container>\n    <span class=\"text-gray-800 text-sm font-semibold ml-2 truncate\" (click)=\"btnApercuNews(false)\">{{currentEditor.name}}</span>\n  </div>\n  <div class=\" mt-2\">\n    <div class=\"flex items-center space-x-3\">\n      <ng-container>\n        <svg (click)=\"likeCurrentHeadline()\" *ngIf=\"currentUser && !currentHedline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5\" />\n        </svg>\n        <svg (click)=\"likeCurrentHeadline()\" *ngIf=\"currentUser && currentHedline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-blue-900\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path d=\"M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z\" />\n        </svg>\n      </ng-container>\n\n      <ng-container>\n        <svg *ngIf=\"currentUser && !currentUser.archives.includes(currentHedline.id)\" (click)=\"archiveCurrentHeadline()\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\" />\n        </svg>\n        <svg *ngIf=\"currentUser && currentUser.archives.includes(currentHedline.id)\" (click)=\"archiveCurrentHeadline()\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-orange-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path d=\"M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z\" />\n        </svg>\n      </ng-container>\n      <svg (click)=\"btnApercuNews(false)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n        <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z\" />\n      </svg>\n      <span class=\"flex items-center ml-2 items-center\" (click)=\"btnApercuNews(true)\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 mr-1\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z\" />\n        </svg>\n          {{currentComment.length}}\n      </span>\n    </div>\n  </div>\n</div>\n\n<div *ngIf=\"skin === 'list' && currentHedline && currentEditor && (idCategory === '' || currentEditor.idCategory === idCategory)\" class=\"flex mb-2 max-w-md bg-white shadow-lg rounded-lg overflow-hidden\">\n  <div class=\"w-1/3 bg-cover bg-landscape\" (click)=\"btnApercuNews(false)\">\n    <img class=\"rounded-t-lg\" [src]=\"currentHedline && currentHedline.image ? currentHedline.image : '...'\" alt=\"Loading...\">\n  </div>\n  <div class=\"w-2/3 p-4\">\n    <div (click)=\"btnApercuNews(false)\" class=\"text-black font-semibold text-xl truncate\">\n      <small class=\"truncate\">{{getValueTraduct(currentHedline.title)}}</small>\n    </div>\n    <div class=\"flex items-center ion-align-items-center\" *ngIf=\"currentEditor\">\n      <ng-container>\n        <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && !currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z\" />\n        </svg>\n        <svg (click)=\"likeCurrentEditor()\" *ngIf=\"currentUser && currentUser.editorsLikes.includes(currentEditor.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-red-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path fill-rule=\"evenodd\" d=\"M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z\" clip-rule=\"evenodd\" />\n        </svg>\n      </ng-container>\n      <span class=\"text-gray-800 text-sm font-semibold ml-2 truncate\" (click)=\"btnApercuNews(false)\">{{currentEditor.name}}</span>\n    </div>\n    <div class=\" mt-2\">\n      <div class=\"flex items-center space-x-3\">\n        <ng-container>\n          <svg (click)=\"likeCurrentHeadline()\" *ngIf=\"currentUser && !currentHedline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5\" />\n          </svg>\n          <svg (click)=\"likeCurrentHeadline()\" *ngIf=\"currentUser && currentHedline.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-blue-900\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z\" />\n          </svg>\n        </ng-container>\n\n        <ng-container>\n          <svg *ngIf=\"currentUser && !currentUser.archives.includes(currentHedline.id)\" (click)=\"archiveCurrentHeadline()\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\" />\n          </svg>\n          <svg *ngIf=\"currentUser && currentUser.archives.includes(currentHedline.id)\" (click)=\"archiveCurrentHeadline()\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 text-orange-500\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z\" />\n          </svg>\n        </ng-container>\n        <svg (click)=\"btnApercuNews(false)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z\" />\n        </svg>\n        <span class=\"flex items-center ml-2 items-center\" (click)=\"btnApercuNews(true)\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"h-6 w-6 mr-1\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n          <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z\" />\n        </svg>\n          {{currentComment.length}}\n      </span>\n      </div>\n    </div>\n    <div (click)=\"btnApercuNews(false)\" class=\"text-gray-700 pt-1 text-xl\">\n      <small class=\"truncate\">{{currentHedline.dateParution | date : 'd/M/yy'}}</small>\n    </div>\n  </div>\n</div>\n\n";

/***/ }),

/***/ 1757:
/*!****************************************************************************************!*\
  !*** ./src/app/shared/print-all-coverage/print-all-coverage.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "<section *ngFor=\"let coverage of listeCoverage\">\n  <app-print-x-coverage idCategory=\"{{!idCat ? '' : idCat}}\" idCoverage=\"{{coverage.id}}\"></app-print-x-coverage>\n</section>\n";

/***/ }),

/***/ 1969:
/*!**********************************************************************************************!*\
  !*** ./src/app/shared/print-recent-headline/print-recent-headline.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

module.exports = "<section class=\"py-3\">\n  <h3 class=\"font-semibold text-xl px-3\">{{'1.1-4' | translate}}</h3>\n  <div class=\"p-3\" *ngIf=\"headlines.length === 0\">\n    <p>{{'1.1-9' | translate}}</p>\n  </div>\n  <ion-slides *ngIf=\"headlines.length > 0\" class=\"ion-padding-vertical\" pager=\"false\" [options]=\"slideOptsNews\">\n    <ion-slide *ngFor=\"let headline of headlines; let i = index\" id=\"headline_{{headline.id}}\">\n      <app-miniature-headline [idCategory]=\"idCategory\" [idHeadline]=\"headline.id\"></app-miniature-headline>\n    </ion-slide>\n  </ion-slides>\n</section>\n";

/***/ }),

/***/ 8753:
/*!************************************************************************************!*\
  !*** ./src/app/shared/print-x-coverage/print-x-coverage.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

module.exports = "<h3 *ngIf=\"headlines.length > 0\" class=\"font-semibold text-xl px-3 capitalize\">{{currentCoverage ? getValueTraduct(currentCoverage.name) : '...'}}</h3>\n\n<ion-slides  class=\"ion-padding-vertical\" pager=\"false\" [options]=\"slideOptsNews\">\n  <ion-slide *ngFor=\"let headline of headlines; let i = index\">\n    <app-miniature-headline [idCategory]=\"idCategory\" [idHeadline]=\"headline.id\"></app-miniature-headline>\n  </ion-slide>\n</ion-slides>\n\n";

/***/ }),

/***/ 4594:
/*!************************************************************************************************!*\
  !*** ./src/app/shared/result-search-headline/result-search-headline.component.html?ngResource ***!
  \************************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"p-3\">\n  <h3 class=\"font-semibold text-xl\">Search result</h3>\n  <div class=\"py-3\" *ngIf=\"headlines.length === 0\">\n    <p>The results will be displayed here</p>\n  </div>\n\n  <app-miniature-headline skin=\"list\" [idCategory]=\"idCategory\" idHeadline=\"{{hl.id}}\" *ngFor=\"let hl of headlines\"></app-miniature-headline>\n</div>\n";

/***/ }),

/***/ 3852:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\" class=\"ion-no-border\">\n  <ion-toolbar color=\"primary\" *ngIf=\"isSearch\">\n    <ion-searchbar [(ngModel)]=\"currentSearch\" (ionCancel)=\"isSearch = !isSearch\" [placeholder]=\"'1.1-5' | translate\" showCancelButton=\"always\"></ion-searchbar>\n  </ion-toolbar>\n  <ion-toolbar color=\"primary\" *ngIf=\"!isSearch\">\n    <ion-buttons slot=\"start\" class=\"ion-no-padding\">\n      <ion-button class=\"ion-no-padding\">\n        <img src=\"https://play-lh.googleusercontent.com/Jf-XEGdn7L1oK6YMvRBUu2ybkT_hDNgyAqEVh_oa1of_jcE8ADE0o2HYArpeFzmGHX8\" width=\"40px\" class=\"inline-block\" height=\"40px\"/>\n      </ion-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\" class=\"font-bold text-3xl\">\n      News\n    </ion-title>\n    <ion-buttons slot=\"end\" class=\"ion-no-padding\">\n      <ion-button class=\"ion-no-padding\" (click)=\"isSearch = !isSearch\">\n        <ion-icon name=\"search\" size=\"large\"></ion-icon>\n      </ion-button>\n      <ion-button (click)=\"presentAllCountry()\" class=\"ion-no-padding space-x-1\">\n        <img *ngIf=\"paySelect && paySelect.flag\" [src]=\"paySelect ? paySelect.flag : ''\" width=\"30px\" class=\"inline-block\" height=\"30px\"/>\n        <ion-icon size=\"large\" *ngIf=\"!paySelect || paySelect && !paySelect.flag\" name=\"flag\"></ion-icon>\n        <span>&#9660;</span>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <!--ion-header collapse=\"condense\">\n    <ion-toolbar class=\"ion-color-danger\">\n      <ion-title size=\"large\">Tab 1</ion-title>\n    </ion-toolbar>\n  </ion-header-->\n\n  <div>\n    <div class=\"grid grid-cols-7 ion-padding-vertical\">\n      <div class=\"col-span-6\">\n        <ion-slides pager=\"false\" [options]=\"slideOpts\">\n          <ion-slide>\n            <span (click)=\"categorieSelect = null\" class=\"{{ categorieSelect === null ? 'bg-blue-900 text-white' : 'bg-white text-gray-400'}} px-9 ion-text-capitalize text-sm font-medium px-2.5 rounded\">{{'1.1-8' | translate}}</span>\n          </ion-slide>\n          <ion-slide *ngFor=\"let cat of categoriesEditors; let i = index\">\n            <span (click)=\"categorieSelect = cat\" class=\"{{ cat === categorieSelect ? 'bg-blue-900 text-white' : 'bg-white text-gray-400'}} px-9 ion-text-capitalize text-sm font-medium px-2.5 rounded\">{{getValueTraduct(cat.name)}}</span>\n          </ion-slide>\n        </ion-slides>\n      </div>\n      <div class=\"col-span-1 ion-text-center text-gray-500 rotate-90 \">\n        <ion-icon name=\"options-sharp\" (click)=\"presentAllCategorie()\"></ion-icon>\n      </div>\n    </div>\n\n    <app-print-recent-headline *ngIf=\"!isSearch\" idCategory=\"{{categorieSelect === null ? '' : categorieSelect.id}}\"></app-print-recent-headline>\n\n    <app-result-search-headline idCategory=\"{{categorieSelect === null ? '' : categorieSelect.id}}\" *ngIf=\"isSearch\" texte=\"{{currentSearch}}\"></app-result-search-headline>\n\n    <app-print-all-coverage idCategory=\"{{categorieSelect === null ? '' : categorieSelect.id}}\"></app-print-all-coverage>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_tab1_tab1_module_ts.js.map