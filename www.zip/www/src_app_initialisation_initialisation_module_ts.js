"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_initialisation_initialisation_module_ts"],{

/***/ 7251:
/*!*****************************************************************!*\
  !*** ./src/app/initialisation/initialisation-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InitialisationPageRoutingModule": () => (/* binding */ InitialisationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _initialisation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./initialisation.page */ 2389);




const routes = [
    {
        path: '',
        component: _initialisation_page__WEBPACK_IMPORTED_MODULE_0__.InitialisationPage
    }
];
let InitialisationPageRoutingModule = class InitialisationPageRoutingModule {
};
InitialisationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], InitialisationPageRoutingModule);



/***/ }),

/***/ 1378:
/*!*********************************************************!*\
  !*** ./src/app/initialisation/initialisation.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InitialisationPageModule": () => (/* binding */ InitialisationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _initialisation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./initialisation-routing.module */ 7251);
/* harmony import */ var _initialisation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./initialisation.page */ 2389);







let InitialisationPageModule = class InitialisationPageModule {
};
InitialisationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _initialisation_routing_module__WEBPACK_IMPORTED_MODULE_0__.InitialisationPageRoutingModule
        ],
        declarations: [_initialisation_page__WEBPACK_IMPORTED_MODULE_1__.InitialisationPage]
    })
], InitialisationPageModule);



/***/ }),

/***/ 2389:
/*!*******************************************************!*\
  !*** ./src/app/initialisation/initialisation.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InitialisationPage": () => (/* binding */ InitialisationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _initialisation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./initialisation.page.html?ngResource */ 5397);
/* harmony import */ var _initialisation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./initialisation.page.scss?ngResource */ 3390);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_authentification_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentification.service */ 4771);
/* harmony import */ var _models_utilisateur__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/utilisateur */ 6888);
/* harmony import */ var _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/utilisateur.service */ 5673);







let InitialisationPage = class InitialisationPage {
    constructor(authService, utilisateurService) {
        this.authService = authService;
        this.utilisateurService = utilisateurService;
        this.message = 'loading...';
    }
    ngOnInit() {
        if (localStorage.getItem('ayoba-tel') && localStorage.getItem('ayoba-name')) {
            this.authService.isSignUp(localStorage.getItem('ayoba-tel')).then((docRef) => {
                if (!docRef) {
                    const tmpUser = new _models_utilisateur__WEBPACK_IMPORTED_MODULE_3__.Utilisateur(localStorage.getItem('ayoba-name'), localStorage.getItem('ayoba-tel'), 'i am using ayoba', '1001');
                    this.authService.signUpUser(tmpUser).then((docRef1) => {
                        localStorage.setItem('id', tmpUser.id);
                        location.reload();
                    });
                }
                else {
                    this.utilisateurService.getUtilisateurWitchPhoneNumber(localStorage.getItem('ayoba-tel')).then((data) => {
                        if (data) {
                            localStorage.setItem('id', data.id);
                            location.reload();
                        }
                        else {
                            this.message = 'Erreur connexion, #NoNumberFound';
                        }
                    });
                }
            });
        }
        else {
            this.message = 'Error loading ayoba data!';
        }
    }
};
InitialisationPage.ctorParameters = () => [
    { type: _services_authentification_service__WEBPACK_IMPORTED_MODULE_2__.AuthentificationService },
    { type: _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_4__.UtilisateurService }
];
InitialisationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-initialisation',
        template: _initialisation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_initialisation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InitialisationPage);



/***/ }),

/***/ 6888:
/*!***************************************!*\
  !*** ./src/app/models/utilisateur.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Utilisateur": () => (/* binding */ Utilisateur)
/* harmony export */ });
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/tools.service */ 7526);

class Utilisateur {
    constructor(userName, phone, status, role) {
        this.userName = userName;
        this.phone = phone;
        this.status = status;
        this.role = role;
        this.photo = '';
        const gid = new _services_tools_service__WEBPACK_IMPORTED_MODULE_0__.ToolsService();
        this.id = gid.generateId(23);
        this.date = new Date().toString();
        this.idCountry = '';
        this.archives = [];
        this.editorsLikes = [];
    }
}


/***/ }),

/***/ 7526:
/*!*******************************************!*\
  !*** ./src/app/services/tools.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToolsService": () => (/* binding */ ToolsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let ToolsService = class ToolsService {
    dec2hex(dec) {
        return ('0' + dec.toString(16)).substr(-2);
    }
    generateId(len) {
        const arr = new Uint8Array((len || 40) / 2);
        window.crypto.getRandomValues(arr);
        return Array.from(arr, this.dec2hex).join('');
    }
};
ToolsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], ToolsService);



/***/ }),

/***/ 3390:
/*!********************************************************************!*\
  !*** ./src/app/initialisation/initialisation.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbml0aWFsaXNhdGlvbi5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 5397:
/*!********************************************************************!*\
  !*** ./src/app/initialisation/initialisation.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<p class=\"p-5 capitalize\">\n  {{message}}\n</p>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_initialisation_initialisation_module_ts.js.map