"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_apercu-news_apercu-news_module_ts"],{

/***/ 3565:
/*!***********************************************************!*\
  !*** ./src/app/apercu-news/apercu-news-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApercuNewsPageRoutingModule": () => (/* binding */ ApercuNewsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _apercu_news_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./apercu-news.page */ 661);




const routes = [
    {
        path: '',
        component: _apercu_news_page__WEBPACK_IMPORTED_MODULE_0__.ApercuNewsPage
    }
];
let ApercuNewsPageRoutingModule = class ApercuNewsPageRoutingModule {
};
ApercuNewsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ApercuNewsPageRoutingModule);



/***/ }),

/***/ 8569:
/*!***************************************************!*\
  !*** ./src/app/apercu-news/apercu-news.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApercuNewsPageModule": () => (/* binding */ ApercuNewsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _apercu_news_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./apercu-news-routing.module */ 3565);
/* harmony import */ var _apercu_news_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./apercu-news.page */ 661);
/* harmony import */ var _shared_miniature_comment_miniature_comment_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/miniature-comment/miniature-comment.component */ 3660);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 8699);









let ApercuNewsPageModule = class ApercuNewsPageModule {
};
ApercuNewsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _apercu_news_routing_module__WEBPACK_IMPORTED_MODULE_0__.ApercuNewsPageRoutingModule,
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule
        ],
        declarations: [_apercu_news_page__WEBPACK_IMPORTED_MODULE_1__.ApercuNewsPage, _shared_miniature_comment_miniature_comment_component__WEBPACK_IMPORTED_MODULE_2__.MiniatureCommentComponent]
    })
], ApercuNewsPageModule);



/***/ }),

/***/ 5407:
/*!**********************************!*\
  !*** ./src/app/models/report.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Report": () => (/* binding */ Report)
/* harmony export */ });
/* harmony import */ var _services_tools_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/tools.service */ 7526);

class Report {
    constructor(idUser, idComment, problemes) {
        this.idUser = idUser;
        this.idComment = idComment;
        this.problemes = problemes;
        const gid = new _services_tools_service__WEBPACK_IMPORTED_MODULE_0__.ToolsService();
        this.id = gid.generateId(23);
        this.date = new Date().toString();
    }
}


/***/ }),

/***/ 3660:
/*!*************************************************************************!*\
  !*** ./src/app/shared/miniature-comment/miniature-comment.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MiniatureCommentComponent": () => (/* binding */ MiniatureCommentComponent)
/* harmony export */ });
/* harmony import */ var C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _miniature_comment_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./miniature-comment.component.html?ngResource */ 1366);
/* harmony import */ var _miniature_comment_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./miniature-comment.component.scss?ngResource */ 2767);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_comment_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/comment.service */ 3792);
/* harmony import */ var _models_comment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/comment */ 7296);
/* harmony import */ var _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/utilisateur.service */ 5673);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/alert.service */ 5970);
/* harmony import */ var _models_report__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../models/report */ 5407);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 8699);












let MiniatureCommentComponent = class MiniatureCommentComponent {
  constructor(translate, alertService, alertController, commentService, userService) {
    this.translate = translate;
    this.alertService = alertService;
    this.alertController = alertController;
    this.commentService = commentService;
    this.userService = userService;
    this.reponseComment = [];
  }

  ngOnInit() {
    this.commentService.getCommentWitchId(this.idComment).then(data => {
      this.currentComment = data;
      this.userService.getUtilisateurWitchId(this.currentComment.idUser).then(data1 => {
        this.currentUserComment = data1;
      });
      this.commentService.getReponseComment(this.idComment).then(data2 => {
        this.reponseComment = data2;
      });
    });
    this.userService.getCurrentUtilisateur().then(data3 => {
      this.currentUser = data3;
    });
  }

  repondreComment() {
    var _this = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let txt1;
      let txt2;

      _this.translate.get('4.4-1').subscribe(res => {
        txt1 = res;
      });

      _this.translate.get('4.4-5').subscribe(res => {
        txt2 = res;
      });

      const alert = yield _this.alertController.create({
        header: '@' + _this.currentUserComment.userName,
        buttons: [{
          text: txt2,
          role: 'confirm',
          handler: reponse => {
            _this.sendComment(reponse.reponse);
          }
        }],
        inputs: [{
          type: 'textarea',
          placeholder: txt1,
          name: 'reponse'
        }]
      });
      yield alert.present();
    })();
  }

  sendComment(texte) {
    if (texte) {
      const tmpComment = new _models_comment__WEBPACK_IMPORTED_MODULE_4__.Comment(this.currentComment.idHeadline, this.currentUser.id, this.currentComment.id, texte);
      this.commentService.addNewComment(tmpComment).then(() => {
        this.reponseComment.unshift(tmpComment);
      });
    }
  }

  diffTime(date) {
    const diff = {};
    const date1 = new Date(date);
    const date2 = new Date();
    let tmp = date2 - date1;
    tmp = Math.floor(tmp / 1000); // Nombre de secondes entre les 2 dates

    diff.sec = tmp % 60;
    tmp = Math.floor((tmp - diff.sec) / 60); // Nombre de minutes (partie entière)

    diff.min = tmp % 60;
    tmp = Math.floor((tmp - diff.min) / 60); // Nombre d'heures (entières)

    diff.hour = tmp % 24;
    tmp = Math.floor((tmp - diff.hour) / 24); // Nombre de jours restants

    diff.day = tmp;
    return diff;
  }

  like() {
    this.commentService.likeComment(this.currentComment).then(() => {
      if (this.currentComment.likes.includes(this.currentUser.id)) {
        this.currentComment.likes.splice(this.currentComment.likes.indexOf(this.currentUser.id), 1);
      } else {
        if (this.currentComment.disLikes.includes(this.currentUser.id)) {
          this.dislike();
        }

        this.currentComment.likes.push(this.currentUser.id);
      }
    });
  }

  dislike() {
    this.commentService.disLikeComment(this.currentComment).then(() => {
      if (this.currentComment.disLikes.includes(this.currentUser.id)) {
        this.currentComment.disLikes.splice(this.currentComment.disLikes.indexOf(this.currentUser.id), 1);
      } else {
        if (this.currentComment.likes.includes(this.currentUser.id)) {
          this.like();
        }

        this.currentComment.disLikes.push(this.currentUser.id);
      }
    });
  }

  presentReport() {
    var _this2 = this;

    return (0,C_Users_Mrs_SEFFI_Documents_projet_ionic_zen_africa_ayoba_news_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let txt1;
      let txt2;
      const txt3 = [];

      _this2.translate.get('4.4-5').subscribe(res => {
        txt1 = res;
      });

      _this2.translate.get('4.4-7').subscribe(res => {
        txt2 = res;
      });

      _this2.translate.get('4.4-8').subscribe(res => {
        txt3[0] = res;
      });

      _this2.translate.get('4.4-9').subscribe(res => {
        txt3[1] = res;
      });

      _this2.translate.get('4.4-10').subscribe(res => {
        txt3[2] = res;
      });

      _this2.translate.get('4.4-11').subscribe(res => {
        txt3[3] = res;
      });

      _this2.translate.get('4.4-12').subscribe(res => {
        txt3[4] = res;
      });

      _this2.translate.get('4.4-13').subscribe(res => {
        txt3[5] = res;
      });

      const alert = yield _this2.alertController.create({
        header: txt2,
        buttons: [{
          text: txt1,
          role: 'confirm',
          handler: raison => {
            _this2.commentService.addNewReport(new _models_report__WEBPACK_IMPORTED_MODULE_7__.Report(_this2.currentUser.id, _this2.idComment, raison)).then(() => {
              _this2.alertService.print('Send with success');
            });
          }
        }],
        inputs: [{
          label: txt3[0],
          type: 'checkbox',
          value: 'red',
          name: 'raison'
        }, {
          label: txt3[1],
          type: 'checkbox',
          value: 'blue',
          name: 'raison'
        }, {
          label: txt3[2],
          type: 'checkbox',
          value: 'green',
          name: 'raison'
        }, {
          label: txt3[3],
          type: 'checkbox',
          value: 'green',
          name: 'raison'
        }, {
          label: txt3[4],
          type: 'checkbox',
          value: 'green',
          name: 'raison'
        }, {
          label: txt3[5],
          type: 'checkbox',
          value: 'green',
          name: 'raison'
        }]
      });
      yield alert.present();
    })();
  }

};

MiniatureCommentComponent.ctorParameters = () => [{
  type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService
}, {
  type: _services_alert_service__WEBPACK_IMPORTED_MODULE_6__.AlertService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController
}, {
  type: _services_comment_service__WEBPACK_IMPORTED_MODULE_3__.CommentService
}, {
  type: _services_utilisateur_service__WEBPACK_IMPORTED_MODULE_5__.UtilisateurService
}];

MiniatureCommentComponent.propDecorators = {
  idComment: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input
  }]
};
MiniatureCommentComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-miniature-comment',
  template: _miniature_comment_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_miniature_comment_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MiniatureCommentComponent);


/***/ }),

/***/ 2767:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/miniature-comment/miniature-comment.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtaW5pYXR1cmUtY29tbWVudC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 1366:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/miniature-comment/miniature-comment.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"grid grid-cols-8 gap-1 my-2\" *ngIf=\"currentComment\">\n  <div class=\"col-span-1\">\n    <img [src]=\"currentUser && currentUser.photo ? currentUser.photo : 'https://cdn-icons-png.flaticon.com/512/149/149071.png'\" width=\"30px\" class=\"inline-block\" height=\"30px\"/>\n  </div>\n  <div class=\"col-span-7 text-sm pb-2\">\n    <div class=\"grid grid-cols-2\">\n      <span class=\"ion-text-left font-bold capitalize\">{{currentUserComment ? currentUserComment.userName : '...'}}</span>\n      <span *ngIf=\"currentUser\" class=\"ion-text-right items-center ion-align-items-center\">\n        <ng-container>\n          <svg (click)=\"like()\" *ngIf=\"!currentComment.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 inline-flex\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5\" />\n          </svg>\n          <svg (click)=\"like()\" *ngIf=\"currentComment.likes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 text-blue-900 inline-flex\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z\" />\n          </svg>\n          {{currentComment.likes.length}}\n        </ng-container>\n        <ng-container>\n          <svg (click)=\"dislike()\" *ngIf=\"!currentComment.disLikes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 inline-flex\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\" stroke-width=\"1\">\n            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.096c.5 0 .905-.405.905-.904 0-.715.211-1.413.608-2.008L17 13V4m-7 10h2m5-10h2a2 2 0 012 2v6a2 2 0 01-2 2h-2.5\" />\n          </svg>\n          <svg (click)=\"dislike()\" *ngIf=\"currentComment.disLikes.includes(currentUser.id)\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 text-red-500 inline-flex\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n            <path d=\"M18 9.5a1.5 1.5 0 11-3 0v-6a1.5 1.5 0 013 0v6zM14 9.667v-5.43a2 2 0 00-1.105-1.79l-.05-.025A4 4 0 0011.055 2H5.64a2 2 0 00-1.962 1.608l-1.2 6A2 2 0 004.44 12H8v4a2 2 0 002 2 1 1 0 001-1v-.667a4 4 0 01.8-2.4l1.4-1.866a4 4 0 00.8-2.4z\" />\n          </svg>\n          &nbsp;{{currentComment.disLikes.length}}\n        </ng-container>\n      </span>\n    </div>\n    <p class=\"py-1 text-gray-500\">{{currentComment.text}}</p>\n    <div class=\"text-gray-400 space-x-5\">\n      <span>\n        {{diffTime(currentComment.date).min < 1 ? 'a few sec ago' : (diffTime(currentComment.date).hour < 1 ? diffTime(currentComment.date).min + ' min ago' : (diffTime(currentComment.date).hour < 24 ? diffTime(currentComment.date).hour + ' hour ago' : (diffTime(currentComment.date).day < 30 ? diffTime(currentComment.date).day + ' days ago' : currentComment.date | date : 'd/M/yy')))}}\n      </span>\n      <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 inline-flex text-gray-500\" (click)=\"repondreComment()\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n          <path fill-rule=\"evenodd\" d=\"M7.707 3.293a1 1 0 010 1.414L5.414 7H11a7 7 0 017 7v2a1 1 0 11-2 0v-2a5 5 0 00-5-5H5.414l2.293 2.293a1 1 0 11-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z\" clip-rule=\"evenodd\" />\n      </svg>\n      <svg (click)=\"presentReport()\" xmlns=\"http://www.w3.org/2000/svg\" class=\"h-4 w-4 inline-flex text-red-400\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n        <path fill-rule=\"evenodd\" d=\"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z\" clip-rule=\"evenodd\" />\n      </svg>\n    </div>\n  </div>\n</div>\n\n<div *ngIf=\"reponseComment.length > 0\" class=\"ml-12\">\n  <app-miniature-comment [idComment]=\"comment.id\" *ngFor=\"let comment of reponseComment\"></app-miniature-comment>\n</div>\n\n<div class=\"{{currentComment && currentComment.idParent ? '' : 'border-b border-gray-200 mb-5'}}\"></div>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_apercu-news_apercu-news_module_ts.js.map